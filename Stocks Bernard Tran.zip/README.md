# cpe545-project
 
To run this project run the following commands

Terminal 1:<br>
javac Server.java<br>
java Server

Terminal 2:<br>
javac Client.java<br>
java Client<br>

To change the methods that are being ran in client call different methods in the Client.java main method.